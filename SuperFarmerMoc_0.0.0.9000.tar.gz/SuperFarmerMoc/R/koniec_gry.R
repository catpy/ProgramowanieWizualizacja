#' Warunek końca gry
#'
#' Funkcja koniec_gry() sprawdza warunek, który pozwala nam zakończyć grę w Superfarmera.
#'
#' @param stado9 Wektor ilości zwierząt w stadzie.



koniec_gry <- function(stado9) {
  all(stado9 >= c(1, 1, 1, 1, 1, 0, 0))
}
