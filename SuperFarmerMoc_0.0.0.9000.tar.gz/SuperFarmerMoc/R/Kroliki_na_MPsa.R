
Kroliki_na_MPsa <- function(stado3) {
  stado3["Krolik"] <- stado3["Krolik"] - 6
  stado3["MalyPies"] <- stado3["MalyPies"] + 1
  return(stado3)
}
