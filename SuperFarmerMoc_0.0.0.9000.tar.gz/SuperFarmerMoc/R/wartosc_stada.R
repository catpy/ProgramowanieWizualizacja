#' Przeliczanie stada na króliki
#'
#' Funkcja przelicza ile nasze stado jest warte w królikach
#'
#' @param stado_tmp Przechowuje wartosc naszego stada
#' @param wartosc_w_krolikach_tmp Przechowuje ile kazdy garunek jest warty w królikach
#'
#' @return Zwraca wartość stada w królikach

wartosc_stada <- function(stado_tmp , wartosc_w_krolikach_tmp){
  wartosc <- 0
  for(j in 1:7){
    wartosc <- wartosc + stado_tmp[j] * wartosc_w_krolikach_tmp[j]
  }
  return(wartosc)
}
