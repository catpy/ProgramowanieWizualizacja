#' Pojedyńcza gra w Superfarmera
#'
#' Funkcja gra() wykonuje jednoosobową grę w Superfarmera dla zadanej strategii gracza.
#'
#' @param strategia_ Strategia, którą ma grać gracz.

gra <- function(strategia_) {

  Stado <- c(0, 0, 0, 0, 0, 0, 0)
  names(Stado) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  MaxZwierzat <- c(60, 24, 20, 12, 6, 4, 2)
  names(MaxZwierzat) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  licznik <- 0
  while (!koniec_gry(Stado)) {
    Stado <- strategia_(Stado)
    names(Stado) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
    if (koniec_gry(Stado)) {break}
    Stado <- po_rzucie(Stado, MaxZwierzat)
    licznik <- licznik + 1
  }
  return(licznik)
}
