uzupelnij_zwierzeta <- function(stado6,Suma_nadwyzki,Wartosc_nadwyzki,Nadwyzka,Cena1) {
  if (stado6["Krolik"] == 0 && stado6["Owca"]>0) {
    stado6 <- Owca_na_Kroliki(stado6) 
  } else {
    for (zwierze in c("Kon","Krowa","Swinia","Owca")) {
      if (Suma_nadwyzki >= Cena1[zwierze] && stado6[zwierze] == 0) {
        stado6 <-Kup(zwierze,stado6,Wartosc_nadwyzki,Nadwyzka,Cena1)
        break()
      }
    }
  }
  return(stado6)
}
