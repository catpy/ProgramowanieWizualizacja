#' Symulacja gier Superfarmer
#'
#' Funkcja badaj_gre() wykonuję 10000 gier dla zadanej strategii.
#'
#' @param strategia_ Funkcja strategii, dla której chcemy wykonać symulację.
#'
#' @export
badaj_gre <- function(strategia_){
  replicate(10000,gra(strategia_))
}
