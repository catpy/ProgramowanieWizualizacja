
MPies_na_Kroliki <- function(stado4) {
  stado4["MalyPies"] <- stado4["MalyPies"] - 1
  stado4["Krolik"] <- stado4["Krolik"] + 6
  return(stado4)
}
