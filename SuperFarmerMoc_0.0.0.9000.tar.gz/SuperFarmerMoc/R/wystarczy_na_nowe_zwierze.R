
wystarczy_na_nowe_zwierze <- function(stado7,Suma_nadwyzki,Cena1) {
  wynik <- FALSE
  for (zwierze in c("Krolik","Owca","Swinia","Krowa","Kon")) {
    if ((Suma_nadwyzki > Cena1[zwierze]) && (stado7[zwierze] == 0)) {
      wynik <- TRUE
    }
  }
  return(wynik)
}
