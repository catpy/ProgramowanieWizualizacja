#' Symulacja rzutu zieloną kostką
#'
#' Wykonuje symulacje rzutu 12-ścienną kostką, która zawiera 6 królików, 3 owce, świnie, krowe i wilka.
rzut_zielona <- function() {
  sample(c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"), 1)
}
