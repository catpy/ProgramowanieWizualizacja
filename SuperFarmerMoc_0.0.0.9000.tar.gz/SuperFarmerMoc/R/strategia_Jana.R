#' Strategia gry superfarmer
#'
#' Funkcja wykonująca całą strategię gry superfarmer
#'
#' @param stado8 Przechowuje ilość poszczególnych zwierząt w stadzie.
#'
#' @return zwraca wektor ilości zwierząt w stadzie po wymianie.
#'
#' @export
strategia_Jana <- function(stado8) {
  #parametry strategii - ile zwierzat zostawiamy, przy ilu krolikach kupujemy 1 i 2 malego psa
  Rozrodcze <- c(24, 1, 1, 1, 1, 4, 2)
  pies1 <- 11
  pies2 <- 17

  Cena1 <- c(1, 6, 12, 36, 72, 6, 36)
  names(Cena1) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")


  Nadwyzka <- pmax(stado8 - Rozrodcze , 0)

  Wartosc_nadwyzki <- Nadwyzka * Cena1

  Suma_nadwyzki <- sum(Wartosc_nadwyzki)

  nazwy_zwierzat <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  names(Cena1) <- nazwy_zwierzat
  names(Nadwyzka) <- nazwy_zwierzat
  names(Wartosc_nadwyzki) <- nazwy_zwierzat
  names(stado8) <- nazwy_zwierzat

  nowe_stado <-Wymiana(stado8, Suma_nadwyzki, Wartosc_nadwyzki, Nadwyzka, pies1, pies2, Cena1)
  names(nowe_stado) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  return(nowe_stado)
}
