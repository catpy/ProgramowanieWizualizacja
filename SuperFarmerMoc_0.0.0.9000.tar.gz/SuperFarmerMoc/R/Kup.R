Kup <- function(zwierze_kupowane,stado,Wartosc_nadwyzki,Nadwyzka,Cena1) {
  
  DoZaplaty<-Cena1[zwierze_kupowane]
  for (zwierze in c("Kon","Krowa","Swinia","Owca","Krolik")) {
    if(DoZaplaty != 0) {
      if (Wartosc_nadwyzki[zwierze] >= DoZaplaty) {
        if (DoZaplaty < Cena1[zwierze]) {
          stado[zwierze] <- stado[zwierze] - 1
          stado[zwierze_kupowane] <- stado[zwierze_kupowane] + (Cena1[zwierze]/Cena1[zwierze_kupowane])
          DoZaplaty <- 0
        } else { 
          stado[zwierze] <- stado[zwierze] - DoZaplaty/Cena1[zwierze]
          stado[zwierze_kupowane] <- stado[zwierze_kupowane] + 1
          DoZaplaty <- 0
        }
      } else {
      stado[zwierze] <- stado[zwierze] - Nadwyzka[zwierze]
      DoZaplaty <- DoZaplaty - Wartosc_nadwyzki[zwierze] 
      }
    }
  }
  return(stado)
}
