#' Symulacja rzutu czerwoną kostką
#'
#' Wykonuje symulacje rzutu 12-ścienną kostką, która zawiera 6 królików, 2 owce, 2 świnie, konia i lisa.
rzut_czerwona <- function() {
  sample(c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis"), 1)
}
