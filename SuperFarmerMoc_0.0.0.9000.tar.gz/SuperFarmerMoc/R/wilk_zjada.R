#' Zmiana stada, gdy wypadł wilk
#'
#' Funkcja wilk_zjada() zmienia wektor stada w przypadku, gdy w wyniku losowania otrzymaliśmy wilka.
#'
#' @param stado12 Wektor ilości zwierząt w stadzie.
wilk_zjada <- function(stado12) {
  if (stado12["DuzyPies"] > 0) {
    stado12["DuzyPies"] <- stado12["DuzyPies"] - 1
  } else {
    for (zwierze in c("Krolik", "Owca", "Swinia", "Krowa")){
      stado12[zwierze] <- 0
    }
  }
  return(stado12)
}
