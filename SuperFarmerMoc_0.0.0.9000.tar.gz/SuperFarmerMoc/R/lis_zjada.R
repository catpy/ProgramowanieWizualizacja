#' Zmiana stada, gdy wypadł lis
#'
#' Funkcja lis_zjada() zmienia wektor stada w przypadku, gdy w wyniku losowania otrzymaliśmy lisa.
#'
#' @param stado13 Wektor ilości zwierząt w stadzie.
lis_zjada <- function(stado13) {
  if (stado13["MalyPies"] > 0) {
    stado13["MalyPies"] <- stado13["MalyPies"] - 1
  } else {
    stado13["Krolik"] <- 0
  }
  return(stado13)
}
