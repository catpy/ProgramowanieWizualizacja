#' Zmiana stada przy znanym wyniku losowania
#'
#' Funkcja przyrost() zmienia wektor zwierząt w stadzie wiedząc, że na kostce pojawiło się konkretne
#' zwierzę. Uwzglednia też ile razy zwierzę występowało na kostkach (może byc 1 lub 2 razy).
#'
#' @param zwierze Argument mówiący jakie zwierzę pojawiło się na kostce.
#' @param liczba_na_kostkach Mówi na ilu kostkach zwierzę wypadło, przyjmuję warości 1 lub 2.
#' @param stado11 Wektor ilości zwierząt w stadzie.
#' @param MaxZwierzat Wektor zawiera informację o ograniczeniach na ilość zwierząt w stadzie.
przyrost <- function(zwierze, liczba_na_kostkach, stado11, MaxZwierzat) {
  if (zwierze != "Wilk" & zwierze != "Lis") {
    stado11[zwierze] <- min(floor((stado11[zwierze] + liczba_na_kostkach) / 2) + stado11[zwierze], MaxZwierzat[zwierze])

  } else if (zwierze == "Lis") {
    stado11 <- lis_zjada(stado11)
  } else {
    stado11 <- wilk_zjada(stado11)
  }
  return(stado11)
}
