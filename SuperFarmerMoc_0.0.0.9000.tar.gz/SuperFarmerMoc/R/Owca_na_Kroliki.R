Owca_na_Kroliki <- function(stado5) {
  stado5["Owca"] <- stado5["Owca"] - 1
  stado5["Krolik"] <- stado5["Krolik"] + 6
  return(stado5)
}
