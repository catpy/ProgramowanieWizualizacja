#' Wartość stada po rzucie kostkami
#'
#' Funkcja po_rzucie() wykonuje rzut kostką zielona oraz czerwoną. Następnie
#' zmienia zawartość stada zgodnie z zasadami gry.
#'
#' @param stado10 Wektor zwierząt posiadanych przez gracza.
#' @param MaxZwierzat Wektor zawierający informację ile maksymalnie możemy posiadać poszczególnych zwierząt.
#'
#' @return Zwraca wektor zwierząt po wymianie.
#'
#' @export

po_rzucie <- function(stado10, MaxZwierzat) {
  names(stado10) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  wynik_zielona <- rzut_zielona()
  wynik_czerwona <- rzut_czerwona()
  if (wynik_zielona == wynik_czerwona) {
    stado10 <- przyrost(wynik_zielona,2,stado10,MaxZwierzat)
  } else {
    stado10 <- przyrost(wynik_zielona, 1, stado10,MaxZwierzat)
    stado10 <- przyrost(wynik_czerwona, 1, stado10,MaxZwierzat)
  }
  names(stado10) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  return(stado10)
}
