#test_that("Wektor ma 10000 elementów",{
#  expect_length(badaj_gre(strategia_Jana),10000)
#})

test_that("strategia_Jana zwraca wektor o odpowiedniej długości",{
  expect_length(strategia_Jana(c(0,0,0,0,0,0,0)), 7)
})

test_that("strategia_Jana zwraca wektor o odpowiednich nazwach",{
  expect_named(strategia_Jana(c(0,0,0,0,0,0,0)), c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies"))
})

test_that("strategia_Jana kupuje małego psa po zjedzeniu zwierząt przez wilka",{
  expect_equivalent(strategia_Jana(c(0,0,0,0,1,1,0)),c(6,0,0,0,1,0,0))
})

test_that("strategia_Jana kupuje pierwszego psa",{
  expect_equivalent(strategia_Jana(c(11,0,0,0,0,0,0)),c(5,0,0,0,0,1,0))
})

test_that("strategia_Jana kupuje drugiego psa",{
  expect_equivalent(strategia_Jana(c(17,0,0,0,0,1,0)),c(11,0,0,0,0,2,0))
})







