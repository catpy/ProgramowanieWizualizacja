#'Funkcja wymiany malego psa na kroliki
#'
#'Wymienia 1 malego psa na 6 krolikow w stadzie gracza.
#'
#'@param stado4 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
MPies_na_Kroliki <- function(stado4) {
  stado4["MalyPies"] <- stado4["MalyPies"] - 1
  stado4["Krolik"] <- stado4["Krolik"] + 6
  return(stado4)
}
