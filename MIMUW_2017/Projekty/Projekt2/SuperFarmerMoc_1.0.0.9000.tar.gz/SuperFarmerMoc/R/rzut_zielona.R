#' Symulacja rzutu zielona kostka
#'
#' Wykonuje symulacje rzutu zadana zielona kostka.
#'
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @return Zwraca nazwe zwierzecia, ktore wypadlo na kostce zielonej.
rzut_zielona <- function(kostka_zielona) {
  sample(kostka_zielona, 1)
}
