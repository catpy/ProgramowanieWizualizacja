#' Podstrategia startegii wiele_na_wiele_MD
#'
#' Funkcja jest wywolywana w strategia_wiele_na_wiele_MD w przypadku, gdy wartosc stada w krolikach jest wieksza niz 127.
#'
#' @param stado_tmp7 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @param wartosc_w_krolikach_tmp7 Siedmioelementowy wektor okreslajacy odpowiednio ile kazdy rodzaj zwierzat jest warty w krolikach.
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.


wiecej_niz_127_wiele_na_wiele <- function(stado_tmp7,wartosc_w_krolikach_tmp7){

DoRozdania <- wartosc_stada(stado_tmp7,wartosc_w_krolikach_tmp7)
stado_tmp7 <- c(1,1,1,1,1,0,0)
nazwy_zwierzat <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
names(stado_tmp7) <- nazwy_zwierzat

MaxZw <- c(60,24,20,12,6,4,2)
names(MaxZw) <- nazwy_zwierzat
DoRozdania <- DoRozdania - wartosc_stada(stado_tmp7,wartosc_w_krolikach_tmp7)
  for (zwierze in c("kon","krowa","swinia","owca","krolik")) {
    x <- 0
    if (DoRozdania > x) {
      if (wartosc_w_krolikach_tmp7[zwierze] < DoRozdania){
        x <- floor(DoRozdania/wartosc_w_krolikach_tmp7[zwierze])
        y <- min(MaxZw[zwierze],1+x)
        stado_tmp7[zwierze] <- y
        DoRozdania <- DoRozdania - (y-1)*wartosc_w_krolikach_tmp7[zwierze]
      }
    }
  }
  return(stado_tmp7)
}
