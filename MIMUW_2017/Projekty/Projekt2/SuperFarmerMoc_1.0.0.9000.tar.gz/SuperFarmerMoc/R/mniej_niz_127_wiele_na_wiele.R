#' Podstrategia startegii wiele_na_wiele_MD
#'
#' Funkcja jest wywolywana w strategia_wiele_na_wiele_MD w przypadku, gdy wartosc stada w krolikach jest mniejsza niz 127.
#'
#' @param stado_tmp7 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @param wartosc_w_krolikach_tmp7 Siedmioelementowy wektor okreslajacy odpowiednio ile kazdy rodzaj zwierzat jest warty w krolikach.
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.

mniej_niz_127_wiele_na_wiele <- function( stado_tmp7 , wartosc_w_krolikach_tmp7 ){
  if(stado_tmp7["kon"] == 0){
    ruch_zmiana <- brak_konia( stado_tmp7, wartosc_w_krolikach_tmp7 )
  } else{
    ruch_zmiana <- jeden_kon_mniej_niz_127( stado_tmp7 )
  }
  if(ruch_zmiana[1] > 0){
    if(ruch_zmiana[2] == 50){
      stado_tmp7 <- zamien_na_duze(ruch_zmiana[1], stado_tmp7, wartosc_w_krolikach_tmp7 )
    } else {
      stado_tmp7 <- zamien_zwierze_na_zwierze(ruch_zmiana[1], ruch_zmiana[2], stado_tmp7, wartosc_w_krolikach_tmp7)
    }
  }
  return (stado_tmp7)
}
