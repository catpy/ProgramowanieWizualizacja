#'Funkcja sprawdzajaca czy mozemy kupic nowe zwierze
#'
#'Sprawdza wartosci parametrow i decyduje.
#'
#'
#'@param stado7 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@param Suma_nadwyzki Zsumowana wartosc nadwyzki zwierzat.
#'@param Cena1 Siedmioelementowy wektor okreslajacy wartosc kazdego ze zwierzat w krolikach
#'@return Wartosc TRUE jesli mozemy uzupelnic zwierzeta, FALSE w przeciwnym przypadku.
wystarczy_na_nowe_zwierze <- function(stado7,Suma_nadwyzki,Cena1) {
  wynik <- FALSE
  for (zwierze in c("Krolik","Owca","Swinia","Krowa","Kon")) {
    if ((Suma_nadwyzki > Cena1[zwierze]) && (stado7[zwierze] == 0)) {
      wynik <- TRUE
    }
  }
  return(wynik)
}
