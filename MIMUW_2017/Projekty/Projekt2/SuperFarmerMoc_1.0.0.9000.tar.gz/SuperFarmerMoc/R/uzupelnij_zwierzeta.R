#'Funkcja uruchamiajaca funkcje Kup dla odpowiedniego zwierzecia
#'
#'Sprawdza jakie najdrozsze brakujace zwierze moze kupic za wartosc nadwyzki zwierzat i to wywoluje.
#'
#'
#'@param stado6 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@param Suma_nadwyzki Zsumowana wartosc nadwyzki zwierzat.
#'@param Wartosc_nadwyzki Liczba rowna wartosci nadwyzki stada podana w wartosciach krolikow.
#'@param Nadwyzka Siedmioelementowy wektor zwierzat okreslajacy ile zwierzat danego rodzaju jest nadwyzkowych.
#'@param Cena1 Siedmioelementowy wektor okreslajacy wartosc kazdego ze zwierzat w krolikach
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
uzupelnij_zwierzeta <- function(stado6,Suma_nadwyzki,Wartosc_nadwyzki,Nadwyzka,Cena1) {
  if (stado6["Krolik"] == 0 && stado6["Owca"]>0) {
    stado6 <- Owca_na_Kroliki(stado6)
  } else {
    for (zwierze in c("Kon","Krowa","Swinia","Owca")) {
      if (Suma_nadwyzki >= Cena1[zwierze] && stado6[zwierze] == 0) {
        stado6 <-Kup(zwierze,stado6,Wartosc_nadwyzki,Nadwyzka,Cena1)
        break()
      }
    }
  }
  return(stado6)
}
