#' Strategia gdy mamy jednego konia
#'
#' Funkcja jest uzywana gdy mamy dokladnie jednego konia, i opracowuje strategie jakie zwierze powinno byc zamienione na jakie.
#'
#' @param stado_tmp6 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @param wartosc_w_krolikach_tmp6 Siedmioelementowy wektor okreslajacy odpowiednio ile kazdy rodzaj zwierzat jest warty w krolikach.
#'
#' @return Zwraca dwuelementowy wektor nazw zwierzat, okreslajacy jakie zwierze ma byc wymienione na jakie.

jeden_kon <- function( stado_tmp6 , wartosc_w_krolikach_tmp6 ){
  ruch_zamiana <- c(0,0)
  if ( wartosc_stada(stado_tmp6, wartosc_w_krolikach_tmp6) >= 144 ) {
    ruch_zamiana <- c("kon", 50)
  } else if (wartosc_stada(stado_tmp6, wartosc_w_krolikach_tmp6) >= 127 ) {
    ruch_zamiana <- jeden_kon_wiecej_niz_127(stado_tmp6)
  } else if (wartosc_stada(stado_tmp6, wartosc_w_krolikach_tmp6) < 127) {
    ruch_zamiana <- jeden_kon_mniej_niz_127(stado_tmp6)
  }
  return (ruch_zamiana)
}
