#' Symulacja rzutu czerwona kostka
#'
#' Wykonuje symulacje rzutu zadana czerwona kostka.
#'
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#' @return Zwraca nazwe zwierzecia, ktore wypadlo na kostce czerwonej.
rzut_czerwona <- function(kostka_czerwona) {
  sample(kostka_czerwona, 1)
}
