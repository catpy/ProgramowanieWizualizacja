#' Zmiana stada, gdy wypadl lis
#'
#' Funkcja lis_zjada zmienia wektor stada w przypadku, gdy w wyniku losowania otrzymalismy lisa.
#'
#' @param stado13 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po dzialaniu lisa.
#' @export
lis_zjada <- function(stado13) {
  if (stado13["MalyPies"] > 0) {
    stado13["MalyPies"] <- stado13["MalyPies"] - 1
  } else {
    stado13["Krolik"] <- 0
  }
  return(stado13)
}
