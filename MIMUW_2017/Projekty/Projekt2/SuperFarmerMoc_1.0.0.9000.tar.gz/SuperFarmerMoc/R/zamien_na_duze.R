#' Wymiana malych zwierzat na duze
#'
#' Funkcja otrzymujac informacje na jakie duze zwierze chcemy wymienic male zwierzaki dokonuje odpowiedniej wymiany
#'
#' @param zwierz przechowuje nazwe zwierzecia ("kon", "swinia" albo "krowa"), na ktore bedziemy chcieli wymienic wiele malych zwierzat
#' @param stado_tmp2 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @param wartosc_w_krolikach_tmp2 Siedmioelementowy wektor okreslajacy odpowiednio ile kazdy rodzaj zwierzat jest warty w krolikach.
#'
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.

zamien_na_duze <- function(zwierz, stado_tmp2 , wartosc_w_krolikach_tmp2){

  if(zwierz == "kon"){
    kolejnosc_zamiany <- c("duzy_pies", "krowa", "swinia", "owca", "maly_pies", "krolik")
  }
  if(zwierz == "swinia"){
    kolejnosc_zamiany <- c("owca", "maly_pies", "krolik")
  }
  if(zwierz == "krowa"){
    kolejnosc_zamiany <- c("duzy_pies", "swinia", "owca", "maly_pies", "krolik")
  }
  do_oddania <- - wartosc_w_krolikach_tmp2[zwierz]
  stado_tmp2[zwierz] <- stado_tmp2[zwierz] + 1
#Kolejnosc zwierzat ma znaczenie! Przechodze od najwiekszych wartosci, tak aby wartosc kolejnych #zwierzat dzielila wartosc poprzednich. W ten sposob nie oddam za duzo zwierzat
  for(j in kolejnosc_zamiany){
    while(do_oddania < 0 && stado_tmp2[j] > 0){
      stado_tmp2[j] <- stado_tmp2[j] - 1
      do_oddania <- do_oddania + wartosc_w_krolikach_tmp2[j]
    }
  }
  return(stado_tmp2)
}
