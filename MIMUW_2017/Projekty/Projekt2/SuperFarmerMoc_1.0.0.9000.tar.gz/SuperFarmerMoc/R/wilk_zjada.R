#' Zmiana stada, gdy wypadl wilk
#'
#' Funkcja wilk_zjada zmienia wektor stada w przypadku, gdy w wyniku losowania otrzymalismy wilka.
#'
#' @param stado12 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po dzialaniu wilka.
#' @export

wilk_zjada <- function(stado12) {
  if (stado12["DuzyPies"] > 0) {
    stado12["DuzyPies"] <- stado12["DuzyPies"] - 1
  } else {
    for (zwierze in c("Krolik", "Owca", "Swinia", "Krowa")){
      stado12[zwierze] <- 0
    }
  }
  return(stado12)
}
