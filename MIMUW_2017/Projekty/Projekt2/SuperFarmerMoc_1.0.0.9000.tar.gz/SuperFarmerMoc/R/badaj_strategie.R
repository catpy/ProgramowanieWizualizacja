#' Symulacja gier Superfarmer z testami
#'
#' Funkcja badaj_strategie wykonuje 10000 gier dla zadanej strategii.
#' Domyslne parametry takie jak w oryginalnej grze Super Farmer.
#' Dziala tak jak funkcja badaj_gre, ale dodatkowo sprawdza po kazdej wymianie:
#' -czy wartosc stada sie nie zmienila (nieprawidlowa wymiana)
#' -czy wartosc stada jest dopuszczalna (nie za duza i nie za mala)
#' Jesli ktorakolwiek z tych rzeczy sie nie zgadza, zwraca w danej grze ilosc rzutow = NA i wypisuje komunikat.
#'
#'
#' @param strategia_ Strategia, ktora ma grac gracz.
#' @param liczba_prob Ile razy gra ma zostac powtorzona.
#' @param Maksimum_zwierzat Wektor zawierajacy informacje ile maksymalnie mozemy posiadac poszczegolnych zwierzat.
#' @param stan_poczatkowy Poczatkowa ilosc zwierzat gracza - wektor siedmioelementowy, kolejno ilosc krolikow, owiec, swin, krow koni, malych psow, duzych psow.
#' @param funkcja_konca_gry Funkcja przyjmujaca za arrgument stado gracza, zwracajaca TRUE jesli gracz wyral gre. Okresla warunki zakonczenia gry.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#' @param wartosci_zwierzat Wektor cen odpowiednich zwierzat (kroliki,owce,swinie,krowy,konie,male psy,duze psy). Stosunek tych cen jest uzywany do obliczenia wartosci stada przed i po wymianie.
#'
#' @return Zwraca wektor czasow (ilosci rzutow kostka) poszczegolnych gier zagranych dana strategia. NA dla gier, w ktorych strategia zadzialala niepoprawnie.
#' @export
#'
badaj_strategie <- function(strategia_,liczba_prob = 10000,Maksimum_zwierzat = c(60,24,20,12,6,4,2), stan_poczatkowy = c(0,0,0,0,0,0,0), funkcja_konca_gry = koniec_gry,funkcja_lisa = lis_zjada,funkcja_wilka = wilk_zjada,kostka_zielona = c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"),kostka_czerwona =c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis"),wartosci_zwierzat = c(1,6,12,36,72,6,36)){
  replicate(liczba_prob,testuj_strategie(strategia_,Maksimum_zwierzat,stan_poczatkowy,funkcja_konca_gry,funkcja_lisa,funkcja_wilka,kostka_zielona,kostka_czerwona,wartosci_zwierzat))
}
