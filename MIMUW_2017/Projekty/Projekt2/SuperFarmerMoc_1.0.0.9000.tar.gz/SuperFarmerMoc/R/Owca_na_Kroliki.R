#'Funkcja wymiany owcy na kroliki
#'
#'Wymienia 1 owce na 6 krolikow w stadzie gracza.
#'
#'@param stado5 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
Owca_na_Kroliki <- function(stado5) {
  stado5["Owca"] <- stado5["Owca"] - 1
  stado5["Krolik"] <- stado5["Krolik"] + 6
  return(stado5)
}
