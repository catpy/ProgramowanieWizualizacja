#' Warunek konca gry
#'
#' Funkcja koniec_gry() sprawdza warunek, ktory pozwala nam zakonczyc gre w Superfarmera.
#'
#' @param stado9 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @return Zwraca wartość TRUE, jesli gra powinna się zakonczyc, FALSE w przeciwnym przypadku.
#' @export



koniec_gry <- function(stado9) {
  all(stado9 >= c(1, 1, 1, 1, 1, 0, 0))
}
