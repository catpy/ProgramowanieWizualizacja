library(testthat)
library(SuperFarmerMoc)

test_check("SuperFarmerMoc")
