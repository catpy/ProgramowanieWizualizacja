library(testthat)
library(SuperFarmerAGOJZB)



test_check("SuperFarmerAGOJZB")
