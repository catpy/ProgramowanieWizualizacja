#'Zbior zawierajacy domyslne wartosci zwierzat.
#'@name wartosc_zwierzat
#'
#'@docType data
#'
NULL
