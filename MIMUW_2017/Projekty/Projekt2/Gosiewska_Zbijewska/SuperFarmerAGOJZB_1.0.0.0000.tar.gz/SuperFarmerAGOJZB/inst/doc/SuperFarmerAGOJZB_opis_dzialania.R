## ----setup, message=FALSE, echo=FALSE------------------------------------
library(SuperFarmerAGOJZB)

## ---- echo=FALSE---------------------------------------------------------
library(knitr)
przykladowe_stado <- c(6, 0, 0, 0, 0, 0, 0)
names(przykladowe_stado) <- c("krolik","owca","swinia","krowa","kon","maly_pies","duzy_pies")

po_popr_wymianie <- c(0, 1, 0, 0, 0, 0, 0)
names(po_popr_wymianie) <- c("krolik","owca","swinia","krowa","kon","maly_pies","duzy_pies")

po_niepopr_wymianie <- c(0, 0, 0, 1, 0, 0, 0)
names(po_niepopr_wymianie) <- c("krolik","owca","swinia","krowa","kon","maly_pies","duzy_pies")

kable(t(przykladowe_stado), caption = "przykladowe_stado")
kable(t(po_popr_wymianie), caption ="po_popr_wymianie")
kable(t(po_niepopr_wymianie), caption ="po_niepopr_wymianie")

## ------------------------------------------------------------------------
SuperFarmerAGOJZB::spr_popr_strategii(przykladowe_stado,po_popr_wymianie)
SuperFarmerAGOJZB::spr_popr_strategii(przykladowe_stado,po_niepopr_wymianie)

## ---- error=TRUE---------------------------------------------------------
SuperFarmerAGOJZB::gra(strategia_AGOJZB)
SuperFarmerAGOJZB::gra(strategia_oszukancza)
SuperFarmerAGOJZB::gra(strategia_oszukancza, sprawdzanie=FALSE)

## ---- warning=FALSE,fig.width=6, fig.height=2.5--------------------------
SuperFarmerAGOJZB::badaj_gre(strategia1=SuperFarmerAGOJZB::strategia_AGOJZB, co_chcesz = "statystyki", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=2.5--------------------------
SuperFarmerAGOJZB::badaj_gre(strategia1=SuperFarmerAGOJZB::strategia_AGOJZB, co_chcesz ="histogram", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=2.5--------------------------
SuperFarmerAGOJZB::badaj_gre(strategia1=SuperFarmerAGOJZB::strategia_AGOJZB, co_chcesz ="wykres_gestosci", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=4, fig.height=2.5--------------------------
SuperFarmerAGOJZB::badaj_gre(strategia1=SuperFarmerAGOJZB::strategia_AGOJZB, co_chcesz ="wykres_skrzypcowy", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=5----------------------------
SuperFarmerAGOJZB::badaj_gre(strategia2=SuperFarmerAGOJZB::strategia_AGOJZB_kroliki,co_chcesz = "statystyki", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=5----------------------------
SuperFarmerAGOJZB::badaj_gre(strategia2=SuperFarmerAGOJZB::strategia_AGOJZB_kroliki, co_chcesz ="histogram", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=5----------------------------
SuperFarmerAGOJZB::badaj_gre(strategia2=SuperFarmerAGOJZB::strategia_AGOJZB_kroliki, co_chcesz ="wykres_gestosci", ilosc_wywolan=1000)

## ---- warning=FALSE,fig.width=6, fig.height=5----------------------------
SuperFarmerAGOJZB::badaj_gre(strategia2=SuperFarmerAGOJZB::strategia_AGOJZB_kroliki, co_chcesz ="wykres_skrzypcowy", ilosc_wywolan=1000)

## ------------------------------------------------------------------------
load("partie.rda")
head(profil$by.total)

load("partie_comp.rda")
head(profil_compiled$by.total)

