## ---- echo=FALSE---------------------------------------------------------
library(SuperFarmerAGOJZB)

## ---- message=FALSE, error=TRUE, fig.width=6, fig.height=5---------------
library(SuperFarmer.SuperDziewczyn)
SuperFarmer.SuperDziewczyn::gra(SuperFarmerAGOJZB::strategia_AGOJZB)
SuperFarmerAGOJZB::gra(SuperFarmer.SuperDziewczyn::strategia_wymian_0_0_0_0)
SuperFarmerAGOJZB::gra(SuperFarmer.SuperDziewczyn::strategia_wymian_1_1_1_1)
SuperFarmerAGOJZB::gra(SuperFarmer.SuperDziewczyn::strategia_owce)
SuperFarmerAGOJZB::badaj_gre(strategia2=SuperFarmer.SuperDziewczyn::strategia_owce, ilosc_wywolan = 1000, co_chcesz = "wykres_gestosci")

## ---- message=FALSE, error=TRUE------------------------------------------
library(SuperFarmer.SuperPakiet)
SuperFarmerAGOJZB::gra(SuperFarmer.SuperPakiet::strategia_1_na_wiele)

## ---- message=FALSE, error=TRUE, fig.width=6, fig.height=5---------------
library(SuperFarmerMAPA)
SuperFarmerAGOJZB::badaj_gre(ilosc_wywolan = 10, strategia1 = SuperFarmerMAPA::strategia_rf, co_chcesz = "histogram")
SuperFarmerMAPA::gra(SuperFarmerAGOJZB::strategia_AGOJZB)

## ---- message=FALSE, error=TRUE, fig.width=6, fig.height=5---------------
library(SuperFarmerMoc)
SuperFarmerAGOJZB::badaj_gre(ilosc_wywolan = 1000, strategia1 = SuperFarmerMoc::strategia_postMDiPR, co_chcesz = "histogram")
SuperFarmerAGOJZB::badaj_gre(ilosc_wywolan = 1000, strategia2 = SuperFarmerMoc::strategia_Jana, co_chcesz = "wykres_gestosci")

