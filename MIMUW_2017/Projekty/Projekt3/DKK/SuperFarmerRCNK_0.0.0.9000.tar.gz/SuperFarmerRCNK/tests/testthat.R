library(testthat)
library(SuperFarmerRCNK)

test_check("SuperFarmerRCNK")
