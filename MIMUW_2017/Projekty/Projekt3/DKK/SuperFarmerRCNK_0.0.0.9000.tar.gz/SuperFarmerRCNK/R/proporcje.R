#' @title Proporcje
#' 
#' @param dobra strategia_nk
#' @param startegia startegia, ktora chcemy badac
#' @param zla strategia_yolo
#'
#' @export
proporcje <- function(dobra, zla, strategia){
  statystyka = c(0,0,0,0)
  #kolejnosc: ("zla_przegrywa","zla_wygrywa", "dobra_przegrywa", "dobra_wygrywa")
  for(i in 1:10000){
    if(dobra[i] > strategia[i])
      statystyka[3] = statystyka[3] + 1
    if(dobra[i] < strategia[i])
      statystyka[4] = statystyka[4] + 1
    if(zla[i] > strategia[i])
      statystyka[1] = statystyka[1] + 1
    if(zla[i] < strategia[i])
      statystyka[2] = statystyka[2] + 1
  }
  statystyka <- statystyka/100
  statystyka
}
