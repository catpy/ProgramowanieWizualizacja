#' @title Zakup malego psa
#'
#' @description 
#' Funkcja pomocnicza strategii ANTY-YOLO, kupujaca malego psa obronnego, jesli nas stac
#'
#' @param stan_gracza Wektor bedacy stanem stada gracza
#' 
#' @export

ruch_gracz_anty_yolo_zakup_malego_psa <- function(stan_gracza) {
  return (zakup_zwierzecia(stan_gracza, 6))
}
