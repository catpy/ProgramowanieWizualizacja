#' @title Wykres dystrybuanty2
#' 
#' @param dobra strategia_nk
#' @param startegia startegia, ktora chcemy badac
#' @param zla strategia_yolo
#' @param tytul_dystryb Jak chcemy nazwac wykres
#' @param osx_dystryb Nazwa osi x
#' @param osy_dystryb Nazwa osi y
#' 
#' 
#'@export
dystryb <- function(dobra, strategia, zla, tytul_dystryb = "Dystrybuanty empiryczne", osx_dystryb = "", osy_dystryb = "") {

  strategie <- data.frame(dobra, strategia, zla)


   dystryb <- ggplot(strategie) +
    stat_ecdf(aes(dobra), geom = "step",color = "gray36"  ,na.rm = TRUE)+
     stat_ecdf(aes(strategia), geom = "step",color = "darkorange" ,na.rm = TRUE)+
     stat_ecdf(aes(zla), geom = "step",color = "gray78"   ,na.rm = TRUE) +
    labs(title = tytul_dystryb) +
    labs(x = osx_dystryb, y = osy_dystryb) +
    theme_minimal()+
    theme(legend.title = element_blank()) +
    theme(legend.position = "bottom")

  dystryb
}
