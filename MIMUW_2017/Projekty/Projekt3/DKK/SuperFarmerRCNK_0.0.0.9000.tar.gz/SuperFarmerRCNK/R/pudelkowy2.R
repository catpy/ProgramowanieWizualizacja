#' @title Statystyki
#' 
#' @param dobra strategia_nk
#' @param startegia startegia, ktora chcemy badac
#' @param zla strategia_yolo
#' 
#' @export
pudelkowy2 <- function(dobra, strategia, zla) {

  strategie <- cbind(dobra, strategia, zla)
  strategie_melt <- melt(strategie)

  strategie_filtr <- filter(strategie_melt, X2 == "strategia")

  median <- round(median(strategie_filtr$value), digits = 4)
  q25 <- quantile(strategie_filtr$value, 0.25)
  q75 <- quantile(strategie_filtr$value, 0.75)

  stat <- c(q25, median, q75)

  stat
}

