#' @title Wykres histogram
#'
#' @description
#' Tworzenie histogramu
#'
#' @export

histo <- function(dobra, strategia, zla, tytul_histo = "Rozklad liczby rzutow obu strategii", osx_histo = "Liczba rzutow", osy_histo = "Prawdopodobienstwo",
                  nazwa_strat = "2. strategia", nazwa_dobra = "1. strategia_nk", nazwa_zla = "3. strategia_yolo") {
  library("reshape")
  strategie <- cbind(dobra, strategia, zla)
  colnames(strategie) <- c( nazwa_dobra, nazwa_strat, nazwa_zla)
  strategie_melt <- melt(strategie)
  
  histo <- ggplot(strategie_melt, aes(value, fill = X2)) +
    geom_density(alpha = 0.5) +
    labs(title = tytul_histo) +
    labs(x = osx_histo, y = osy_histo) +
    theme_minimal() +
    theme(legend.title = element_blank()) +
    theme(legend.position = "bottom") +
    scale_fill_manual(values= c( "gray36", "darkorange", "gray78"))
  
  histo
}
