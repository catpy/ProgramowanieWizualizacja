#' @title Wykres dystrybuanty
#'
#' @description
#' Tworzenie dystrybuanty
#'
#' @export

czasowy <- function(dobra1, strategia1, zla1, tytul_czasowy = "Liczba rzutow w kolejnych grach", osx_czasowy = "Numer gry", osy_czasowy = "Liczba rzutow") {
  dobra <- sort(dobra1)
  zla <- sort(zla1)
  strategia <- sort(strategia1)

  strategie <- cbind(dobra, strategia,zla)

  id <- c(1:10000)
  nazwy <- c("dobra","strategia", "zla")
  strategie_numerowane <- structure( strategie ,.Dim=c(10000,3) ,.Dimnames=list( c(id), c(nazwy) ))
  strategie_numerowane_melt <- melt(strategie_numerowane)


  czasowy <- ggplot() + 
    geom_point(data =strategie_numerowane_melt , aes(x=X1, y = value, group = X2, colour=X2), size = 0.5) +
    labs(title = tytul_czasowy) + 
    labs(x=osx_czasowy, y=osy_czasowy ) + 
    scale_color_manual(values= c( "gray36", "darkorange", "gray78")) +
    theme_minimal() +
    theme(legend.title=element_blank()) +
    theme(legend.position="bottom")
  
  czasowy
}

