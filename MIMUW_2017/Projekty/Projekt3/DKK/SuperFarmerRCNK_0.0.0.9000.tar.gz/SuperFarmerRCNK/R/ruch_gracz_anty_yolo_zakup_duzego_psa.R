#' @title Zakup duzego psa
#'
#' @description 
#' Funkcja pomocnicza strategii ANTY-YOLO, kupujaca duzego psa obronnego, jesli nas stac
#'
#' @param stan_gracza Wektor bedacy stanem stada gracza
#' 
#' @export

ruch_gracz_anty_yolo_zakup_duzego_psa <- function(stan_gracza) {
  return (zakup_zwierzecia(stan_gracza, 7))
}
