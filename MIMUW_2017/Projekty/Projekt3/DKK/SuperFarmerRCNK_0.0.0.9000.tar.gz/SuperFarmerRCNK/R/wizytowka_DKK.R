#' @title Export do pdf
#'
#' @description
#' Zapis do pdf
#'
#' @export
#' 
wizytowka_DKK <- function(strategia1, tytul = "Strategia prosta", nazwa_pliku = 'Wizytowka.pdf',
                       tytul_czasowy = "Liczba rzutow w kolejnych grach", osx_czasowy = "Numer gry", osy_czasowy = "Liczba rzutow",
                       tytul_skrzypcowy = "Porownanie podstawowych statystyk", osx_skrzypcowy = "", osy_skrzypcowy = "Liczba rzutow",
                       tytul_histo = "Rozklad liczby rzutow wszystkich strategii", osx_histo = "Liczba rzutow", osy_histo = "Prawdopodobienstwo",
                       nazwa_strat1 = "prosta", nazwa_dobra = "MDiPR", nazwa_zla1 = "losowa") {
  
  nazwa_strat <- paste(" ", nazwa_strat1, sep = "") 
  nazwa_zla <- paste("  ", nazwa_zla1, sep ="")
  
  #odpalenie strategii
  strategia <- badaj_gre(gra, strategia1)

  #pobieranie danych z pakieru
  dobra <- s_MDiPR
  zla <- s_yolo

  histo <- histo(dobra, strategia, zla, tytul_histo, osx_histo, osy_histo,  nazwa_strat, nazwa_dobra , nazwa_zla )

  #czasowy <- czasowy(dobra, strategia, zla, tytul_czasowy, osx_czasowy, osy_czasowy)

  dystr <- dystryb(dobra, strategia, zla)

  skrzypcowy <- skrzypcowy(dobra, strategia, zla, tytul_skrzypcowy, osx_skrzypcowy, osy_skrzypcowy, nazwa_strat, nazwa_dobra, nazwa_zla )

  stat <- pudelkowy2(dobra, strategia ,zla)

  prop <- proporcje(dobra, zla, strategia)

  wykresy <- ggdraw() +
    draw_plot(skrzypcowy, 0, .47, .5, .47) +
    draw_plot(histo, 0, 0, .5, .47) +
    draw_plot(dystr, .5, .05, .5, .47) +
    draw_label(tytul, fontface='bold', hjust = 0.5, vjust = -27, colour = "orange2") +
    draw_label(paste("25 centyl wynosi", stat[1], sep = " "), hjust = -.4, vjust = -32, size = 9) +
    draw_label(paste("Mediana wynosi", stat[2], sep = " "), hjust = -.4, vjust = -28, size = 9) +
    draw_label(paste("75 centyl wynosi", stat[3], sep = " "), hjust = -.36, vjust = -23.5, size = 9) +
    draw_label(paste("Strategia wygrywa z strategia MDiPR", prop[3], "% razy, przegrywa",prop[4],"% razy", sep = " "), hjust = -.105, vjust = -19, size = 9) +
    draw_label(paste("Strategia wygrywa ze strategia losowa", prop[1], "% razy, przegrywa",prop[2],"% razy", sep = " "), hjust = -.1, vjust = -15, size = 9) +
    draw_label(paste("Wykonali: Marianna Dzik, Natalia Kneblewska, Adam Krol."), hjust = -.1, vjust = 43.26, size=9)

  ggsave(nazwa_pliku, wykresy, width =11.69, height = 8.27)
}


