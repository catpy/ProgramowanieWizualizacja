#' @title Wykres skrzypcowy
#'
#' @description
#' Tworzenie wykresu skrzypcowego
#'
#' @export

skrzypcowy <- function (dobra, strategia, zla, tytul_skrzypcowy = "Porowanie podstawowych statystyk", osx_skrzypcowy = "", osy_skrzypcowy = "Liczba rzutow",
                        nazwa_strat = "2. strategia", nazwa_dobra = "1. strategia_nk", nazwa_zla = "3. strategia_yolo"){
  library("reshape")
  strategie <- cbind(  dobra, strategia, zla)
  colnames(strategie) <- c( nazwa_dobra, nazwa_strat, nazwa_zla)
  strategie_melt <- melt(strategie)
  
  p <- ggplot(strategie_melt, aes(x=X2, y=value,fill = X2)) +
    stat_summary(fun.data="mean_sdl", geom="crossbar", width=0.1) +
    geom_violin(trim=FALSE, alpha = 0.4) +
    labs(title=tytul_skrzypcowy,x=osx_skrzypcowy, y = osy_skrzypcowy) +
    theme_minimal() +
    coord_cartesian(ylim = c(0, 700)) +
    theme(legend.position="none") +
    coord_flip() +
    scale_fill_manual(values= c("gray36","darkorange", "gray78"))
  p
}
