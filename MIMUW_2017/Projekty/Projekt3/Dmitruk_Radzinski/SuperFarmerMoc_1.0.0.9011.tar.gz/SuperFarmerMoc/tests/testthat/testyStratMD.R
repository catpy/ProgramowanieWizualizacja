#brak_konia
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10,1,1,1,0,1,1)),c(10,1,1,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10,0,0,0,0,0,0)),c(4,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10,0,1,0,0,1,0)),c(22,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10,1,0,0,0,1,0)),c(16,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0,0,0,0,0,1,0)),c(6,0,0,0,0,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(40, 1, 0,0,0,2,0)),c(34,2,0,0,0,2,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(47, 0, 0,0,0,2,0)),c(35,0,1,0,0,2,0))
})

#jeden_kon
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(36, 0, 0,1,1,0,0)),c(0,0,0,0,2,0,0))
})
#do poprawy tu jest to jeden_kon_wiecej_niz_127
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0,2,1,1,1,0,0)),c(36,2,1,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(1,0,2,1,1,0,0)),c(1,6,2,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(1,3,0,1,1,0,0)),c(1,3,3,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0,3,4,0,1,0,0)),c(12,3,3,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10,0,4,0,1,0,0)),c(10,2,3,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0,10,0,0,1,0,0)),c(6,9,0,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(59,0,0,0,1,0,0)),c(53,1,0,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(26,6,0,0,1,0,0)),c(26,4,1,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(20,6,1,0,1,0,0)),c(20,2,0,1,1,0,0))
})

#jeden_kon_mniej_niz_127
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(10, 0, 0,0,1,0,0)),c(4, 0, 0,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0, 0, 0,0,1,1,0)),c(6, 0, 0,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(16, 0, 0,0,1,1,0)),c(10, 1, 0,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(21, 1, 0,0,1,1,0)),c(9, 1, 1,0,1,1,0))
})
#wiecej niz jeden kon
test_that("Poprawna wymiana w strategia_postMDiPR",{
  expect_equivalent(strategia_postMDiPR(c(0,0,0,0,2,0,0)),c(6,1,2,1,1,0,0))
})















