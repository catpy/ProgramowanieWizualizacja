#brak_konia
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10,1,1,1,0,1,1)),c(10,1,1,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10,0,0,0,0,0,0)),c(4,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10,0,1,0,0,1,0)),c(22,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10,1,0,0,0,1,0)),c(16,0,0,0,0,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(0,0,0,0,0,1,0)),c(6,0,0,0,0,0,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(40, 1, 0,0,0,2,0)),c(34,2,0,0,0,2,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(47, 0, 0,0,0,2,0)),c(35,0,1,0,0,2,0))
})

#jeden_kon_mniej_niz_127
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10, 0, 0,0,1,0,0)),c(4, 0, 0,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(0, 0, 0,0,1,1,0)),c(6, 0, 0,0,1,0,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(16, 0, 0,0,1,1,0)),c(10, 1, 0,0,1,1,0))
})
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(21, 1, 0,0,1,1,0)),c(9, 1, 1,0,1,1,0))
})

#wiecej_niz_127_wiele_na_wiele
test_that("Poprawna wymiana w strategia_wiele_na_wiele_MD",{
  expect_equivalent(strategia_wiele_na_wiele_MD(c(10,0,2,4,0,0,0)),c(4, 1, 2,2,1,0,0))
})














