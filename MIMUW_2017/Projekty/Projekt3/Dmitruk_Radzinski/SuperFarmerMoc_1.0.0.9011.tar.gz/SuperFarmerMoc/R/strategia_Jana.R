#' Strategia gry superfarmer
#'
#' Funkcja wykonuje co najwyzej jedna wymiane, wedlug oryginalnych zasad gry Super Farmer.
#' Ponadto stosuje przy tym konkretna strategie:
#' -kupuje pierwszego malego psa, jesli go nie posiada, przy 11 krolikach
#' -kupuje drugiego malego psa, jesli go nie posiada, przy 17 krolikach
#' -nigdy nie wymienia pierwszych 24 krolikow, 1 owcy, 1 swini, 1 krowy, 1 konia, psow
#' -wszystkie zwierzeta ponad te wyzej wymienione zlicza i kupuje za nie brakujace zwierzeta jak najszybciej (duzego psa przed krowa)
#' -jesli brakuje tylko konia, kupuje druga krowe, zeby szybciej zebrac na konia
#'
#' @param stado8 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie, nazwany wektorem c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
#'
#' @export
strategia_Jana <- function(stado8) {
  #parametry strategii - ile zwierzat zostawiamy, przy ilu krolikach kupujemy 1 i 2 malego psa
  Rozrodcze <- c(24, 1, 1, 1, 1, 4, 2)
  pies1 <- 11
  pies2 <- 17


  Cena1 <- c(1, 6, 12, 36, 72, 6, 36)
  names(Cena1) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")

  Nadwyzka <- pmax(stado8 - Rozrodcze , 0)

  Wartosc_nadwyzki <- Nadwyzka * Cena1

  Suma_nadwyzki <- sum(Wartosc_nadwyzki)

  nazwy_zwierzat <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  names(Cena1) <- nazwy_zwierzat
  names(Nadwyzka) <- nazwy_zwierzat
  names(Wartosc_nadwyzki) <- nazwy_zwierzat
  names(stado8) <- nazwy_zwierzat

  nowe_stado <-Wymiana(stado8, Suma_nadwyzki, Wartosc_nadwyzki, Nadwyzka, pies1, pies2, Cena1)
  names(nowe_stado) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  return(nowe_stado)
}
