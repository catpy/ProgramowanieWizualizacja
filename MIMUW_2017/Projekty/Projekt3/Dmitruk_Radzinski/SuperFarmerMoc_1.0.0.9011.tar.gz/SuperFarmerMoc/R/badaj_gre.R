#' Symulacja gier Superfarmer
#'
#' Funkcja badaj_gre() wykonuje wybrana liczbe gier dla zadanej strategii.
#' Domyslne parametry takie jak w oryginalne grze Super Farmer.
#'
#' @param strategia_ Strategia, ktora gra gracz.
#' @param liczba_prob Ile razy gra ma zostac powtorzona.
#' @param Maksimum_zwierzat Wektor zawierajacy informacje ile maksymalnie mozemy posiadac poszczegolnych zwierzat.
#' @param stan_poczatkowy Poczatkowa ilosc zwierzat gracza - wektor siedmioelementowy, kolejno ilosc krolikow, owiec, swin, krow koni, malych psow, duzych psow.
#' @param funkcja_konca_gry Funkcja przyjmujaca za argument stado gracza, zwracajaca TRUE jesli gracz wygral gre, FALSE w przeciwnym przypadku. Okresla warunki zakonczenia gry.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierze ta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#'
#' @return Zwraca wektor czasow (ilosci rzutow kostka) poszczegolnych gier zagranych dana strategia.
#' @export
badaj_gre <- function(strategia_,liczba_prob = 10000,Maksimum_zwierzat = c(60,24,20,12,6,4,2), stan_poczatkowy = c(0,0,0,0,0,0,0), funkcja_konca_gry = koniec_gry,funkcja_lisa = lis_zjada,funkcja_wilka = wilk_zjada,kostka_zielona = c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"),kostka_czerwona =c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis")){
  replicate(liczba_prob,gra(strategia_,Maksimum_zwierzat,stan_poczatkowy,funkcja_konca_gry,funkcja_lisa,funkcja_wilka,kostka_zielona,kostka_czerwona))
}
