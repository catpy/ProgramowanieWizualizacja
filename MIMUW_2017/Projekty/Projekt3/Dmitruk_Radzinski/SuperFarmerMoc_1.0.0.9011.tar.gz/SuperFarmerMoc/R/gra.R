#' Pojedyncza gra w Superfarmera
#'
#' Funkcja gra() wykonuje jednoosobowa gre w Superfarmera dla zadanej strategii gracza i parametrow gry.
#' Domyslne parametry takie jak w oryginalnej grze Super Farmer.
#'
#' @param strategia_ Strategia, ktora ma grac gracz.
#' @param Maksimum_zwierzat Wektor zawierajacy informacje ile maksymalnie mozemy posiadac poszczegolnych zwierzat.
#' @param stan_poczatkowy Poczatkowa liczba zwierzat gracza - wektor siedmioelementowy, kolejno ilosc krolikow, owiec, swin, krow koni, malych psow, duzych psow
#' @param funkcja_konca_gry Funkcja przyjmujaca za arrgument stado gracza, zwracajaca TRUE jesli gracz wygral gre. Okresla warunki zakonczenia gry.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#'
#' @return Zwraca liczbe rzutow kostkami, ktora byla potrzebna do wygranej.
#' @export

gra <- function(strategia_, Maksimum_zwierzat = c(60,24,20,12,6,4,2), stan_poczatkowy = c(0,0,0,0,0,0,0), funkcja_konca_gry = koniec_gry,funkcja_lisa = lis_zjada,funkcja_wilka = wilk_zjada,kostka_zielona = c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"),kostka_czerwona =c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis")) {

  Stado <- stan_poczatkowy
  names(Stado) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  MaxZwierzat <- Maksimum_zwierzat
  names(MaxZwierzat) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  licznik <- 0
  while (!funkcja_konca_gry(Stado)) {
    Stado <- strategia_(Stado)
    names(Stado) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
    if (funkcja_konca_gry(Stado)) {break}
    Stado <- po_rzucie(Stado, MaxZwierzat,funkcja_lisa,funkcja_wilka,kostka_zielona,kostka_czerwona)
    licznik <- licznik + 1
  }
  return(licznik)
}
