#' Wartosc stada po rzucie kostkami
#'
#' Funkcja po_rzucie() wykonuje rzut kostka zielona oraz czerwona. Nastepnie
#' zmienia zawartosc stada zgodnie z zasadami gry. Parametry domyslnie sa takie, jak w oryginalnych zasadach gry Suoer Farmer.
#' Obsluguje dowolne dwie kostki, oprocz sytuacji 2 wilkow lub 2 lisow, wiec wilk i lis moga wystepowac odpowiednio na tylko jednej z kostek.
#'
#'
#' @param stado10 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#' @param MaxZwierzat Wektor zawierajacy informacje ile maksymalnie mozemy posiadac poszczegolnych zwierzat.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#'
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po rzucie kostkami, nazwany wektorem c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
#' @export


po_rzucie <- function(stado10, MaxZwierzat = c(60,24,20,12,6,4,2), funkcja_lisa = lis_zjada, funkcja_wilka = wilk_zjada ,kostka_zielona  = c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"),kostka_czerwona =c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis")) {
  names(stado10) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  wynik_zielona <- rzut_zielona(kostka_zielona)
  wynik_czerwona <- rzut_czerwona(kostka_czerwona)
  if (wynik_zielona == wynik_czerwona) {
    stado10 <- przyrost(wynik_zielona,2,stado10,MaxZwierzat,funkcja_lisa,funkcja_wilka)
  } else {
    stado10 <- przyrost(wynik_zielona, 1, stado10,MaxZwierzat,funkcja_lisa,funkcja_wilka)
    stado10 <- przyrost(wynik_czerwona, 1, stado10,MaxZwierzat,funkcja_lisa,funkcja_wilka)
  }
  names(stado10) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  return(stado10)
}
