#' Strategia gry superfarmer postMDiPR przy zalozeniu, ze mozemy wymieniac wiele zwierzat na wiele
#'
#' Funkcja wykonujaca cala strategie "postMDiPR" gry superfarmer przy zmienionych zalozeniach gry. Zakladamy, ze mozemy
#'  wymieniac wiele zwierzat na wiele. od pierwotnej startegii rozni sie tym, ze gre konczymy, gdy wartosc stada w krolikach
#'  jest wieksza niz 127.
#'
#' @param stado_tmp9 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
#'
#' @export

strategia_wiele_na_wiele_MD <- function( stado_tmp9 ){
  wartosc_w_krolikach = c(1, 6, 12, 36, 72, 6, 36)
  nazwy_zwierzat <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  names(wartosc_w_krolikach) <- nazwy_zwierzat
  names(stado_tmp9) <- nazwy_zwierzat

  if (wartosc_stada(stado_tmp9, wartosc_w_krolikach) < 127) {
    stado_tmp9 <- mniej_niz_127_wiele_na_wiele( stado_tmp9, wartosc_w_krolikach )
  } else {
    stado_tmp9 <- wiecej_niz_127_wiele_na_wiele( stado_tmp9, wartosc_w_krolikach )
  }
  return(stado_tmp9)

}
