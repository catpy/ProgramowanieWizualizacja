#' Zmiana stada przy znanym wyniku losowania kostkami.
#'
#' Funkcja przyrost() zmienia wektor zwierzat w stadzie, wiedzac, ze na kostce pojawilo sie konkretne
#' zwierze. Uwzglednia tez ile razy zwierze wystepowalo na kostkach (moze byc 1 lub 2 razy).
#'
#' @param zwierze Argument mowiacy jakie zwierze pojawilo sie na kostce.
#' @param liczba_na_kostkach Mowi na ilu kostkach zwierze wypadlo, przyjmuje warosci 1 albo 2.
#' @param stado11 Wektor liczby zwierzat w stadzie.
#' @param MaxZwierzat Wektor zawiera informacje o ograniczeniach na liczbe zwierzat w stadzie.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie.
przyrost <- function(zwierze, liczba_na_kostkach, stado11, MaxZwierzat,funkcja_lisa,funkcja_wilka) {
  if (zwierze != "Wilk" & zwierze != "Lis") {
    stado11[zwierze] <- min(floor((stado11[zwierze] + liczba_na_kostkach) / 2) + stado11[zwierze], MaxZwierzat[zwierze])

  } else if (zwierze == "Lis") {
    stado11 <- funkcja_lisa(stado11)
  } else {
    stado11 <- funkcja_wilka(stado11)
  }
  return(stado11)
}
