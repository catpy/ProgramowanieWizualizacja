#'Funkcja wymiany krolikow na malego psa
#'
#'Wymienia 6 krolikow na 1 malego psa w stadzie gracza.
#'
#'@param stado3 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
Kroliki_na_MPsa <- function(stado3) {
  stado3["Krolik"] <- stado3["Krolik"] - 6
  stado3["MalyPies"] <- stado3["MalyPies"] + 1
  return(stado3)
}
