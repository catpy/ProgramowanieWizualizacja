#'Funkcja decydujaca, ktora z wymian powinna zajsc.
#'
#'Sprawdza wartosci parametrow i decyduje.
#'
#'
#'@param Stado2 Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@param Suma_nadwyzki Zsumowana wartosc nadwyzki zwierzat.
#'@param Wartosc_nadwyzki Liczba rowna wartosci nadwyzki stada podana w wartosciach krolikow.
#'@param Nadwyzka Siedmioelementowy wektor zwierzat okreslajacy ile zwierzat danego rodzaju jest nadwyzkowych.
#'@param pies1 Liczba krolikow, przy ktorej kupowany jest pierwszy pies.
#'@param pies2 Liczba krolikow, przy ktorej kupowany jest drugi pies.
#'@param Cena1 Siedmioelementowy wektor okreslajacy wartosc kazdego ze zwierzat w krolikach
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
Wymiana <- function(Stado2, Suma_nadwyzki, Wartosc_nadwyzki, Nadwyzka, pies1, pies2, Cena1){
  if (all(Stado2[c("Krolik", "Owca", "Swinia", "Krowa")] == c(0, 0, 0, 0)) && Stado2["MalyPies"] > 0) {
    Stado2 <- MPies_na_Kroliki(Stado2)
  } else if ( Stado2["Krolik"] >= pies1 && Stado2["MalyPies"] < 1 ) {
    Stado2 <- Kroliki_na_MPsa(Stado2)
  } else if ( wystarczy_na_nowe_zwierze(Stado2,Suma_nadwyzki,Cena1) ) {
    Stado2 <- uzupelnij_zwierzeta(Stado2,Suma_nadwyzki,Wartosc_nadwyzki,Nadwyzka,Cena1)
  } else if ( Suma_nadwyzki >= Cena1["DuzyPies"] && Stado2["DuzyPies"] < 1 ){
    Stado2 <- Kup("DuzyPies",Stado2,Wartosc_nadwyzki,Nadwyzka,Cena1)
  } else if ( Suma_nadwyzki >= Cena1["Krowa"] && Stado2["Krowa"] < 2 ) {
    Stado2 <- Kup("Krowa",Stado2,Wartosc_nadwyzki,Nadwyzka,Cena1)
  } else if ( Stado2["Krolik"] >= pies2 && Stado2["MalyPies"] < 2 ){
   Stado2 <- Kroliki_na_MPsa(Stado2)
  }
  return(Stado2)
}
