#'Funkcja kupujaca zwierze za nadwyzke innych zwierzat.
#'
#'Kupuje jak najwiecej wybranych zwierzat, placac jak najdrozszymi zwierzetami z nadwyzki i respektujac zasade wymian jedno na wiele, badz wiele na jedno.
#'
#'@param zwierze_kupowane Nazwa zwierzecia, ktore chcemy kupic: Krolik, Owca, Swinia, Krowa, Kon, MalyPies, DuzyPies
#'@param stado Siedmioelementowy wektor liczby zwierzat w stadzie gracza. Zwierzeta w ustalonej kolejnosci: kroliki, owce, swinie, krowy, konie, male psy, duze psy.
#'@param Wartosc_nadwyzki Liczba rowna wartosci nadwyzki stada podana w wartosciach krolikow.
#'@param Nadwyzka Siedmioelementowy wektor zwierzat okreslajacy ile zwierzat danego rodzaju jest nadwyzkowych.
#'@param Cena1 Siedmioelementowy wektor okreslajacy wartosc kazdego ze zwierzat w krolikach
#'@return Zwraca siedmioelementowy wektor liczby zwierzat w stadzie po wymianie.
Kup <- function(zwierze_kupowane,stado,Wartosc_nadwyzki,Nadwyzka,Cena1) {

  DoZaplaty<-Cena1[zwierze_kupowane]
  for (zwierze in c("Kon","Krowa","Swinia","Owca","Krolik")) {
    if(DoZaplaty != 0) {
      if (Wartosc_nadwyzki[zwierze] >= DoZaplaty) {
        if (DoZaplaty < Cena1[zwierze]) {
          stado[zwierze] <- stado[zwierze] - 1
          stado[zwierze_kupowane] <- stado[zwierze_kupowane] + (Cena1[zwierze]/Cena1[zwierze_kupowane])
          DoZaplaty <- 0
        } else {
          stado[zwierze] <- stado[zwierze] - DoZaplaty/Cena1[zwierze]
          stado[zwierze_kupowane] <- stado[zwierze_kupowane] + 1
          DoZaplaty <- 0
        }
      } else {
      stado[zwierze] <- stado[zwierze] - Nadwyzka[zwierze]
      DoZaplaty <- DoZaplaty - Wartosc_nadwyzki[zwierze]
      }
    }
  }
  return(stado)
}
