#' Pojedyncza gra w Superfarmera z testami
#'
#' Funkcja testuj_strategie wykonuje jednoosobowa gre w Superfarmera dla zadanej strategii gracza i parametrow gry.
#' Domyslne parametry takie jak w oryginalnej grze Super Farmer.
#' Dziala tak jak funkcja gra, ale dodatkowo sprawdza po kazdej wymianie:
#' -czy wartosc stada sie nie zwiększyła (nieprawidlowa wymiana)
#' -czy wartosc stada jest dopuszczalna (nie za duza i nie za mala)
#' Jesli ktorakolwiek z tych rzeczy sie nie zgadza, zwraca w danej grze ilosc rzutow = NA i wypisuje komunikat.
#'
#' @param strategia_ Strategia, ktora ma grac gracz.
#' @param Maksimum_zwierzat Wektor zawierajacy informacje ile maksymalnie mozemy posiadac poszczegolnych zwierzat.
#' @param stan_poczatkowy Poczatkowa ilosc zwierzat gracza - wektor siedmioelementowy, kolejno ilosc krolikow, owiec, swin, krow koni, malych psow, duzych psow
#' @param funkcja_konca_gry Funkcja przyjmujaca za arrgument stado gracza, zwracajaca TRUE jesli gracz wyral gre. Okresla warunki zakonczenia gry.
#' @param funkcja_lisa Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu lisa.
#' @param funkcja_wilka Funkcja, ktora okresla co sie dzieje ze stadem po wypadnieciu wilka.
#' @param kostka_zielona Wektor nazw zwierzat, ktore sa na kostce zielonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce zielonej.
#' @param kostka_czerwona Wektor nazw zwierzat, ktore sa na kostce czerwonej. Okresla jakie zwierzeta i z jaka czestotliwoscia wypadaja na kostce czerwonej.
#' @param wartosci_zwierzat Wektor cen odpowiednich zwierzat (kroliki,owce,swinie,krowy,konie,male psy,duze psy). Stosunek tych cen jest uzywany do obliczenia wartosci stada przed i po wymianie.
#'
#' @return Zwraca liczbe rzutow kostkami, ktora byla potrzebna do wygranej. NA jesli strategia zadzialala niepoprawnie.
#' @export

testuj_strategie <- function(strategia_, Maksimum_zwierzat = c(60,24,20,12,6,4,2), stan_poczatkowy = c(0,0,0,0,0,0,0), funkcja_konca_gry = koniec_gry,funkcja_lisa = lis_zjada,funkcja_wilka = wilk_zjada,kostka_zielona = c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Owca", "Swinia", "Krowa", "Wilk"),kostka_czerwona =c("Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Krolik", "Owca", "Owca", "Swinia", "Swinia", "Kon", "Lis"),wartosci_zwierzat = c(1,6,12,36,72,6,36)) {

  Stado <- stan_poczatkowy
  names(Stado) <- c("krolik", "owca", "swinia", "krowa", "kon", "maly_pies", "duzy_pies")
  MaxZwierzat <- Maksimum_zwierzat
  names(MaxZwierzat) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
  licznik <- 0
  while (!funkcja_konca_gry(Stado)) {
    wartosc1 <- 0
    wartosc_zwierzat <- wartosci_zwierzat
    for (i in 1:7) {
      wartosc1 <- wartosc1 +Stado[i]*wartosc_zwierzat[i]
    }
    Stado <- strategia_(Stado)
    wartosc2 <- 0
    for (i in 1:7) {
      wartosc2 <- wartosc2 +Stado[i]*wartosc_zwierzat[i]
    }
    if(wartosc1 < wartosc2){
      cat("niedozwolona wymiana!  ")
      licznik <- NA
      break()
    }
    if (!all(Stado>=0)){
        cat("Za malo zwierzat!  ")
        licznik <- NA
        break()
    }
if (!all(Stado<=Maksimum_zwierzat)){
  cat("Za duzo zwierzat!  ")
  licznik <- NA
  break()
}


    names(Stado) <- c("Krolik", "Owca", "Swinia", "Krowa", "Kon", "MalyPies", "DuzyPies")
    if (funkcja_konca_gry(Stado)) {break}
    Stado <- po_rzucie(Stado, MaxZwierzat,funkcja_lisa,funkcja_wilka,kostka_zielona,kostka_czerwona)
    licznik <- licznik + 1
  }
  return(licznik)
}
